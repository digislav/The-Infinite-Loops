'use client';

import { cn } from '@/lib/utils';

const STAGES = ['All', 'Interested', 'Applied', 'Interview', 'Offer', 'Rejected', 'Archived'];

export function BoardControls() {
  return (
    <div className="flex flex-wrap items-center gap-2">
      {STAGES.map((stage) => (
        <button
          key={stage}
          className={cn(
            'px-3 py-1.5 text-sm font-medium rounded-md border border-gray-200',
            'bg-white text-gray-600 hover:bg-gray-50 transition-colors',
            stage === 'All' && 'bg-[#2E75B6] text-white border-[#2E75B6] hover:bg-[#1F4E79]',
          )}
        >
          {stage}
        </button>
      ))}
    </div>
  );
}
